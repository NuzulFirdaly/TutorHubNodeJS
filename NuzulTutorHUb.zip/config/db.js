

module.exports = {

    host: 'localhost',
    database:'tutorhub',
    username:'tutorhubadmin',
    password:'tutorhubadmin123'
}