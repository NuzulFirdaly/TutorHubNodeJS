import { Input } from './input';
import { MbscFormOptions } from './forms';

export class Select extends Input {
    constructor(element: any, settings: MbscFormOptions);
    _setText(): void;
}