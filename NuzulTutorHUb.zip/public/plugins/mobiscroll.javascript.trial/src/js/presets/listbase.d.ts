import { Scroller, MbscScrollerOptions } from '../classes/scroller';

export class List<T extends MbscScrollerOptions> extends Scroller<T> {
}